<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/*
 * All messages
 */
if ( ! function_exists( 'trav_get_message' ) ) {
	function trav_get_message( $key ) {
		$messages = array(
			);
	}
}