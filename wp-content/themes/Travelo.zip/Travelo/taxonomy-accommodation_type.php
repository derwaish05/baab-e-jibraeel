<?php
/**
 * The Template for displaying accommodations in a accommodation_type category . Simply includes the archive template.
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

trav_get_template( 'archive-accommodation.php' );